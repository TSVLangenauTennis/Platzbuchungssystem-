import Link from "next/link";
import { AdminNav } from "@/components/AdminNav";
import { updateCourtSettings } from "@/app/actions";
import { nowInClubTimezone, toDateInputValue } from "@/lib/dates";
import { requireAdmin } from "@/lib/auth";
import type { Booking, Court } from "@/lib/types";
import { BOOKING_COLUMNS } from "@/lib/types";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

function nowLocalIso(): string {
  const now = nowInClubTimezone();
  const hh = String(now.getHours()).padStart(2, "0");
  const min = String(now.getMinutes()).padStart(2, "0");
  return `${toDateInputValue(now)}T${hh}:${min}:00`;
}

export default async function CourtsPage({ searchParams }: { searchParams: SearchParams }) {
  const params = await searchParams;
  const { supabase } = await requireAdmin();

  const [{ data: courts }, { data: futureBookings }] = await Promise.all([
    supabase.from("courts").select("id, name, is_active").order("id", { ascending: true }).returns<Court[]>(),
    supabase
      .from("bookings")
      .select(BOOKING_COLUMNS)
      .gte("starts_at", nowLocalIso())
      .is("cancelled_at", null)
      .order("starts_at", { ascending: true })
      .returns<Booking[]>()
  ]);

  const success = typeof params.success === "string" ? params.success : undefined;
  const error = typeof params.error === "string" ? params.error : undefined;
  const bookingsByCourt = new Map<number, number>();
  (futureBookings ?? []).forEach((booking) => bookingsByCourt.set(booking.court_id, (bookingsByCourt.get(booking.court_id) ?? 0) + 1));

  return (
    <main className="page">
      <header className="header">
        <div className="brand">
          <h1>Admin: Plätze</h1>
          <p>Platznamen und aktive Buchbarkeit verwalten. Für Wartung besser Sperrzeiten nutzen; Deaktivieren ist für längere Ausfälle gedacht.</p>
        </div>
        <div className="header-actions">
          <Link className="button secondary" href="/">Zur Buchung</Link>
        </div>
      </header>

      <AdminNav />

      {success ? <p className="notice success">{success}</p> : null}
      {error ? <p className="notice error">{error}</p> : null}

      <section className="court-grid">
        {(courts ?? []).map((court) => (
          <article className="card court-card" key={court.id}>
            <div className="court-card-head">
              <span className={court.is_active ? "pill approved" : "pill pending"}>{court.is_active ? "Aktiv" : "Deaktiviert"}</span>
              <small>{bookingsByCourt.get(court.id) ?? 0} kommende aktive Einträge</small>
            </div>
            <form action={updateCourtSettings} className="form-stack">
              <input type="hidden" name="courtId" value={court.id} />
              <label>
                Platzname
                <input name="name" defaultValue={court.name} required minLength={2} maxLength={40} />
              </label>
              <label className="switch-row">
                <input type="checkbox" name="isActive" defaultChecked={court.is_active} />
                <span>Für Mitglieder buchbar</span>
              </label>
              <button type="submit">Platz speichern</button>
            </form>
          </article>
        ))}
      </section>

      <section className="card info-card">
        <strong>Hinweis zur sicheren Platzverwaltung</strong>
        <p>
          Ein Platz kann nicht deaktiviert werden, solange kommende Mitgliedsbuchungen darauf liegen. Für einzelne Trainingseinheiten,
          Pflege oder Turniere verwenden Sie weiter feste Termine/Sperrzeiten auf der Buchungsseite.
        </p>
      </section>
    </main>
  );
}
