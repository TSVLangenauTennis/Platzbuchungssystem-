import { redirect } from "next/navigation";
import { assertBookableDate, assertBookableSlot } from "@/lib/dates";
import { createClient } from "@/lib/supabase/server";
import type { CalendarView } from "@/lib/types";

export { assertBookableDate, assertBookableSlot };

// Ersetzt die frühere Sammlung von sieben fast identischen
// redirectToX(type, message)-Funktionen. Jede Seite ruft weiterhin ihre
// eigene kleine, klar benannte Variante auf (siehe unten) - die eigentliche
// URL-Bau-Logik steht aber nur noch einmal hier.
export function redirectWithMessage(
  path: string,
  type: "success" | "error",
  message: string,
  extraParams?: Record<string, string>
): never {
  const params = new URLSearchParams({ ...extraParams, [type]: message });
  redirect(`${path}?${params.toString()}`);
}

export function redirectToCalendar(date: string, view: CalendarView, type: "success" | "error", message: string): never {
  redirectWithMessage("/", type, message, { date, view });
}

export function redirectToHome(type: "success" | "error", message: string): never {
  redirectWithMessage("/", type, message);
}

export function redirectToMembers(type: "success" | "error", message: string): never {
  redirectWithMessage("/admin/members", type, message);
}

export function redirectToAccount(type: "success" | "error", message: string): never {
  redirectWithMessage("/account", type, message);
}

export function redirectToAdminBookings(type: "success" | "error", message: string): never {
  redirectWithMessage("/admin/bookings", type, message);
}

export function redirectToCourts(type: "success" | "error", message: string): never {
  redirectWithMessage("/admin/courts", type, message);
}

export function redirectToAnnouncements(type: "success" | "error", message: string): never {
  redirectWithMessage("/ankundigungen", type, message);
}

export async function getCurrentUserOrRedirect() {
  const supabase = await createClient();
  const { data: userData } = await supabase.auth.getUser();
  const user = userData.user;
  if (!user) redirect("/login");
  return { supabase, user };
}

export async function assertAdmin() {
  const { supabase, user } = await getCurrentUserOrRedirect();
  const { data: profile } = await supabase.from("profiles").select("is_admin").eq("id", user.id).single();
  if (!profile?.is_admin) redirect("/");
  return { supabase, user };
}
