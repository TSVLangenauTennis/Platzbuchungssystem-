"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { nowInClubTimezone, toDateInputValue } from "@/lib/dates";
import { assertAdmin, redirectToCourts } from "./shared";

const courtSettingsSchema = z.object({
  courtId: z.coerce.number().int().min(1).max(5),
  name: z.string().trim().min(2).max(40),
  isActive: z.string().optional()
});

export async function updateCourtSettings(formData: FormData) {
  const parsed = courtSettingsSchema.safeParse({
    courtId: formData.get("courtId"),
    name: formData.get("name"),
    isActive: formData.get("isActive") || ""
  });

  if (!parsed.success) redirectToCourts("error", "Platzdaten sind ungültig.");

  const { supabase } = await assertAdmin();
  const shouldBeActive = parsed.data.isActive === "on";

  if (!shouldBeActive) {
    const now = nowInClubTimezone();
    const localNow = `${toDateInputValue(now)}T${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}:00`;
    const { count, error: countError } = await supabase
      .from("bookings")
      .select("id", { count: "exact", head: true })
      .eq("court_id", parsed.data.courtId)
      .eq("kind", "member")
      .is("cancelled_at", null)
      .gte("starts_at", localNow);

    if (countError) redirectToCourts("error", "Aktive Buchungen konnten nicht geprüft werden.");
    if ((count ?? 0) > 0) {
      redirectToCourts("error", "Platz kann erst deaktiviert werden, wenn keine kommenden Mitgliedsbuchungen mehr darauf liegen.");
    }
  }

  const { error } = await supabase
    .from("courts")
    .update({ name: parsed.data.name, is_active: shouldBeActive })
    .eq("id", parsed.data.courtId);

  if (error) redirectToCourts("error", "Platz konnte nicht gespeichert werden.");

  revalidatePath("/");
  revalidatePath("/admin");
  revalidatePath("/admin/courts");
  redirectToCourts("success", "Platz gespeichert.");
}
