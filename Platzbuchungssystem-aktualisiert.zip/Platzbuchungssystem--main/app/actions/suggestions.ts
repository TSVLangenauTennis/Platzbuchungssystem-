"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { assertAdmin, getCurrentUserOrRedirect, redirectToHome } from "./shared";

const suggestionSchema = z.object({
  message: z.string().trim().min(3).max(1000)
});

export async function submitSuggestion(formData: FormData) {
  const parsed = suggestionSchema.safeParse({
    message: formData.get("message")
  });

  if (!parsed.success) {
    redirectToHome("error", "Bitte einen etwas längeren Vorschlag eingeben (mind. 3 Zeichen).");
  }

  const { supabase } = await getCurrentUserOrRedirect();

  const { error } = await supabase.rpc("submit_suggestion", {
    p_message: parsed.data.message
  });

  if (error) redirectToHome("error", "Vorschlag konnte nicht gespeichert werden.");

  revalidatePath("/");
  redirectToHome("success", "Danke für Ihren Vorschlag! Er wurde anonym übermittelt.");
}

const markSuggestionSchema = z.object({ id: z.string().uuid() });

export async function markSuggestionRead(formData: FormData) {
  const parsed = markSuggestionSchema.safeParse({ id: formData.get("id") });
  if (!parsed.success) return;

  const { supabase } = await assertAdmin();
  await supabase.from("suggestions").update({ is_read: true }).eq("id", parsed.data.id);
  revalidatePath("/admin/vorschlaege");
}
