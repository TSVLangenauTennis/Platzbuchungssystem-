"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { assertAdmin, redirectToMembers } from "./shared";

const memberSchema = z.object({ profileId: z.string().uuid() });

// Bündelt approveMember/revokeMemberApproval/grantAdmin/removeAdmin, die sich
// bis auf die update-Felder und die Selbstschutz-Prüfung alle gleichen.
async function updateMemberStatus(
  formData: FormData,
  options: {
    buildUpdate: (adminId: string) => Record<string, unknown>;
    preventSelf?: boolean;
    selfErrorMessage?: string;
    errorMessage: string;
    successMessage: string;
  }
) {
  const parsed = memberSchema.safeParse({ profileId: formData.get("profileId") });
  if (!parsed.success) redirectToMembers("error", "Mitglied konnte nicht gelesen werden.");

  const { supabase, user } = await assertAdmin();

  if (options.preventSelf && parsed.data.profileId === user.id) {
    redirectToMembers("error", options.selfErrorMessage ?? "Diese Aktion ist für das eigene Konto nicht möglich.");
  }

  const { error } = await supabase
    .from("profiles")
    .update(options.buildUpdate(user.id))
    .eq("id", parsed.data.profileId);

  if (error) redirectToMembers("error", options.errorMessage);
  revalidatePath("/admin/members");
  redirectToMembers("success", options.successMessage);
}

export async function approveMember(formData: FormData) {
  return updateMemberStatus(formData, {
    buildUpdate: (adminId) => ({ is_approved: true, approved_at: new Date().toISOString(), approved_by: adminId }),
    errorMessage: "Mitglied konnte nicht freigegeben werden.",
    successMessage: "Mitglied freigegeben."
  });
}

export async function approveAllPendingMembers() {
  const { supabase, user } = await assertAdmin();
  const { error } = await supabase
    .from("profiles")
    .update({ is_approved: true, approved_at: new Date().toISOString(), approved_by: user.id })
    .eq("is_approved", false)
    .eq("is_admin", false);

  if (error) redirectToMembers("error", "Ausstehende Mitglieder konnten nicht gesammelt freigegeben werden.");
  revalidatePath("/admin/members");
  redirectToMembers("success", "Alle wartenden Mitglieder wurden freigegeben.");
}

export async function revokeMemberApproval(formData: FormData) {
  return updateMemberStatus(formData, {
    buildUpdate: () => ({ is_approved: false, approved_at: null, approved_by: null, is_admin: false }),
    preventSelf: true,
    selfErrorMessage: "Sie können Ihre eigene Freigabe nicht entfernen.",
    errorMessage: "Freigabe konnte nicht entfernt werden.",
    successMessage: "Freigabe entfernt."
  });
}

export async function grantAdmin(formData: FormData) {
  return updateMemberStatus(formData, {
    buildUpdate: (adminId) => ({ is_admin: true, is_approved: true, approved_at: new Date().toISOString(), approved_by: adminId }),
    errorMessage: "Admin-Recht konnte nicht vergeben werden.",
    successMessage: "Admin-Recht vergeben."
  });
}

export async function removeAdmin(formData: FormData) {
  return updateMemberStatus(formData, {
    buildUpdate: () => ({ is_admin: false }),
    preventSelf: true,
    selfErrorMessage: "Sie können sich nicht selbst die Admin-Rechte entziehen.",
    errorMessage: "Admin-Recht konnte nicht entfernt werden.",
    successMessage: "Admin-Recht entfernt."
  });
}
