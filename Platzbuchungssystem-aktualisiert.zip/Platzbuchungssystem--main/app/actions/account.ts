"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { MIN_PASSWORD_LENGTH, SITE_URL } from "@/lib/config";
import { createClient } from "@/lib/supabase/server";
import { getCurrentUserOrRedirect, redirectToAccount } from "./shared";

export async function updateOwnProfile(formData: FormData) {
  const parsed = z.object({
    fullName: z.string().trim().min(2).max(80),
    phone: z.string().trim().max(40).optional().or(z.literal("")),
    memberNumber: z.string().trim().max(40).optional().or(z.literal(""))
  }).safeParse({
    fullName: formData.get("fullName"),
    phone: formData.get("phone") || "",
    memberNumber: formData.get("memberNumber") || ""
  });

  if (!parsed.success) redirectToAccount("error", "Profilangaben sind unvollständig oder zu lang.");

  const { supabase } = await getCurrentUserOrRedirect();
  const { error } = await supabase.rpc("update_own_profile", {
    p_full_name: parsed.data.fullName,
    p_phone: parsed.data.phone || null,
    p_member_number: parsed.data.memberNumber || null
  });

  if (error) redirectToAccount("error", "Profil konnte nicht gespeichert werden.");
  revalidatePath("/");
  revalidatePath("/account");
  redirectToAccount("success", "Profil gespeichert.");
}

export async function signIn(formData: FormData) {
  const parsed = z.object({
    email: z.string().trim().email(),
    password: z.string().min(1)
  }).safeParse({
    email: formData.get("email"),
    password: formData.get("password")
  });

  if (!parsed.success) redirect(`/login?error=${encodeURIComponent("Bitte E-Mail und Passwort prüfen.")}`);

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword(parsed.data);
  if (error) redirect(`/login?error=${encodeURIComponent("Login fehlgeschlagen.")}`);
  redirect("/");
}

export async function signUp(formData: FormData) {
  const parsed = z.object({
    fullName: z.string().trim().min(2).max(80),
    email: z.string().trim().email(),
    phone: z.string().trim().max(40).optional().or(z.literal("")),
    memberNumber: z.string().trim().max(40).optional().or(z.literal("")),
    password: z.string().min(MIN_PASSWORD_LENGTH),
    website: z.string().optional().or(z.literal("")),
    privacyConsent: z.literal("on")
  }).safeParse({
    fullName: formData.get("fullName"),
    email: formData.get("email"),
    phone: formData.get("phone") || "",
    memberNumber: formData.get("memberNumber") || "",
    password: formData.get("password"),
    website: formData.get("website") || "",
    privacyConsent: formData.get("privacyConsent") || ""
  });

  if (!parsed.success) {
    redirect(`/login?error=${encodeURIComponent(`Registrierung unvollständig. Passwort mindestens ${MIN_PASSWORD_LENGTH} Zeichen, Datenschutz muss bestätigt werden.`)}`);
  }

  if (parsed.data.website) redirect(`/login?error=${encodeURIComponent("Registrierung fehlgeschlagen.")}`);

  const supabase = await createClient();
  const { error } = await supabase.auth.signUp({
    email: parsed.data.email,
    password: parsed.data.password,
    options: {
      data: {
        full_name: parsed.data.fullName,
        phone: parsed.data.phone || null,
        member_number: parsed.data.memberNumber || null
      }
    }
  });

  if (error) redirect(`/login?error=${encodeURIComponent("Registrierung fehlgeschlagen. Eventuell existiert diese E-Mail bereits.")}`);
  redirect(`/login?success=${encodeURIComponent("Registrierung angelegt. Ein Admin muss das Konto freigeben, bevor Plätze gebucht werden können.")}`);
}

export async function requestPasswordReset(formData: FormData) {
  const parsed = z.object({ email: z.string().trim().email() }).safeParse({ email: formData.get("email") });
  if (!parsed.success) redirect(`/login?error=${encodeURIComponent("Bitte geben Sie eine gültige E-Mail-Adresse ein.")}`);

  const supabase = await createClient();
  await supabase.auth.resetPasswordForEmail(parsed.data.email, {
    redirectTo: `${SITE_URL.replace(/\/$/, "")}/reset-password`
  });

  redirect(`/login?success=${encodeURIComponent("Wenn die E-Mail-Adresse registriert ist, wurde eine Nachricht zum Zurücksetzen des Passworts verschickt.")}`);
}

export async function updatePassword(formData: FormData) {
  const parsed = z.object({ password: z.string().min(MIN_PASSWORD_LENGTH) }).safeParse({ password: formData.get("password") });
  if (!parsed.success) redirect(`/reset-password?error=${encodeURIComponent(`Passwort mindestens ${MIN_PASSWORD_LENGTH} Zeichen.`)}`);

  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser({ password: parsed.data.password });
  if (error) redirect(`/reset-password?error=${encodeURIComponent("Passwort konnte nicht gespeichert werden. Bitte fordern Sie den Link erneut an.")}`);

  redirect(`/login?success=${encodeURIComponent("Passwort gespeichert. Sie können sich jetzt einloggen.")}`);
}

export async function signOut() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/login");
}
