"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { MAX_WEEKLY_REPEAT_OCCURRENCES, MEMBER_BOOKING_LEAD_MINUTES } from "@/lib/config";
import { adminEndTimes, adminStartTimes, bookingStartTimes, createWeeklyDates, getSlotLocal, getTimeRangeLocal, isValidTimeOption, parseViewParam, timeToMinutes, toDateInputValue } from "@/lib/dates";
import type { BookingKind } from "@/lib/types";
import {
  assertAdmin,
  assertBookableSlot,
  getCurrentUserOrRedirect,
  redirectToAdminBookings,
  redirectToCalendar
} from "./shared";

const bookingSchema = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  startTime: z.string().regex(/^\d{2}:\d{2}$/),
  courtId: z.coerce.number().int().min(1).max(5),
  notes: z.string().trim().max(120).optional().or(z.literal("")),
  view: z.enum(["day", "week"]).optional()
});

export async function bookCourt(formData: FormData) {
  const view = parseViewParam(String(formData.get("view") ?? "day"));
  const parsed = bookingSchema.safeParse({
    date: formData.get("date"),
    startTime: formData.get("startTime"),
    courtId: formData.get("courtId"),
    notes: formData.get("notes") || "",
    view: formData.get("view") || "day"
  });

  if (!parsed.success) redirectToCalendar(String(formData.get("date") ?? toDateInputValue()), view, "error", "Ungültige Buchungsdaten.");

  const { date, startTime, courtId, notes } = parsed.data;

  try {
    assertBookableSlot(date, startTime, { leadMinutes: MEMBER_BOOKING_LEAD_MINUTES });
  } catch (error) {
    redirectToCalendar(date, view, "error", error instanceof Error ? error.message : "Buchung nicht möglich.");
  }

  const { supabase, user } = await getCurrentUserOrRedirect();

  const { data: profile } = await supabase
    .from("profiles")
    .select("full_name, is_approved, is_admin")
    .eq("id", user.id)
    .single();

  if (!profile?.is_approved && !profile?.is_admin) {
    redirectToCalendar(date, view, "error", "Ihr Konto ist noch nicht freigegeben.");
  }

  if (!isValidTimeOption(startTime, bookingStartTimes())) {
    redirectToCalendar(date, view, "error", "Diese Startzeit ist nicht buchbar.");
  }

  const { data: court } = await supabase
    .from("courts")
    .select("id, is_active")
    .eq("id", courtId)
    .single();

  if (!court?.is_active) redirectToCalendar(date, view, "error", "Dieser Platz ist aktuell nicht aktiv buchbar.");

  const { startsAt, endsAt } = getSlotLocal(date, startTime);
  const title = profile?.full_name || user.email || "Mitglied";

  const { error } = await supabase.from("bookings").insert({
    court_id: courtId,
    user_id: user.id,
    created_by: user.id,
    title,
    kind: "member",
    starts_at: startsAt,
    ends_at: endsAt,
    notes: notes?.trim() ? notes.trim() : null
  });

  if (error) redirectToCalendar(date, view, "error", "Dieser Platz ist zu dieser Zeit bereits belegt.");

  revalidatePath("/");
  redirectToCalendar(date, view, "success", "Platz gebucht.");
}

const adminMemberBookingSchema = z.object({
  memberId: z.string().uuid(),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  startTime: z.string().regex(/^\d{2}:\d{2}$/),
  courtId: z.coerce.number().int().min(1).max(5),
  notes: z.string().trim().max(120).optional().or(z.literal("")),
  view: z.enum(["day", "week"]).optional()
});

export async function bookCourtForMember(formData: FormData) {
  const view = parseViewParam(String(formData.get("view") ?? "day"));
  const parsed = adminMemberBookingSchema.safeParse({
    memberId: formData.get("memberId"),
    date: formData.get("date"),
    startTime: formData.get("startTime"),
    courtId: formData.get("courtId"),
    notes: formData.get("notes") || "",
    view: formData.get("view") || "day"
  });

  if (!parsed.success) redirectToCalendar(String(formData.get("date") ?? toDateInputValue()), view, "error", "Admin-Buchung unvollständig.");
  const { memberId, date, startTime, courtId, notes } = parsed.data;

  try {
    assertBookableSlot(date, startTime);
  } catch (error) {
    redirectToCalendar(date, view, "error", error instanceof Error ? error.message : "Buchung nicht möglich.");
  }

  if (!isValidTimeOption(startTime, bookingStartTimes())) {
    redirectToCalendar(date, view, "error", "Diese Startzeit ist nicht buchbar.");
  }

  const { supabase, user } = await assertAdmin();

  const [{ data: member }, { data: court }] = await Promise.all([
    supabase
      .from("profiles")
      .select("id, full_name, email, is_approved, is_admin")
      .eq("id", memberId)
      .single(),
    supabase
      .from("courts")
      .select("id, is_active")
      .eq("id", courtId)
      .single()
  ]);

  if (!member || (!member.is_approved && !member.is_admin)) redirectToCalendar(date, view, "error", "Dieses Mitglied ist nicht freigegeben.");
  if (!court?.is_active) redirectToCalendar(date, view, "error", "Dieser Platz ist aktuell nicht aktiv buchbar.");

  const { startsAt, endsAt } = getSlotLocal(date, startTime);
  const { error } = await supabase.from("bookings").insert({
    court_id: courtId,
    user_id: member.id,
    created_by: user.id,
    title: member.full_name || member.email || "Mitglied",
    kind: "member",
    starts_at: startsAt,
    ends_at: endsAt,
    notes: notes?.trim() ? notes.trim() : "Durch Admin gebucht"
  });

  if (error) redirectToCalendar(date, view, "error", "Dieser Platz ist zu dieser Zeit bereits belegt.");

  revalidatePath("/");
  revalidatePath("/admin/bookings");
  redirectToCalendar(date, view, "success", "Buchung für Mitglied erstellt.");
}

const cancelSchema = z.object({
  id: z.string().uuid(),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  view: z.enum(["day", "week"]).optional()
});

export async function cancelBooking(formData: FormData) {
  const parsed = cancelSchema.safeParse({
    id: formData.get("id"),
    date: formData.get("date"),
    view: formData.get("view") || "day"
  });

  if (!parsed.success) {
    redirectToCalendar(toDateInputValue(), "day", "error", "Buchung konnte nicht gelesen werden.");
  }

  const view = parsed.data.view ?? "day";
  const { supabase } = await getCurrentUserOrRedirect();

  const { error } = await supabase.rpc("cancel_own_booking", {
    p_booking_id: parsed.data.id
  });

  if (error) {
    redirectToCalendar(parsed.data.date, view, "error", "Buchung konnte nicht gelöscht werden.");
  }

  revalidatePath("/");
  revalidatePath("/admin/bookings");

  redirectToCalendar(parsed.data.date, view, "success", "Buchung gelöscht.");
}

export async function cancelBookingAsAdmin(formData: FormData) {
  const parsed = z.object({ id: z.string().uuid() }).safeParse({ id: formData.get("id") });
  if (!parsed.success) redirectToAdminBookings("error", "Buchung konnte nicht gelesen werden.");

  const { supabase, user } = await assertAdmin();
  const { error } = await supabase
    .from("bookings")
    .update({ cancelled_at: new Date().toISOString(), cancelled_by: user.id, cancellation_reason: "Gelöscht durch Admin" })
    .eq("id", parsed.data.id);

  if (error) redirectToAdminBookings("error", "Buchung konnte nicht gelöscht werden.");

  revalidatePath("/");
  revalidatePath("/admin/bookings");
  redirectToAdminBookings("success", "Buchung gelöscht.");
}

const adminBlockSchema = z.object({
  title: z.string().trim().min(2).max(80),
  kind: z.enum(["training", "match", "tournament", "maintenance", "blocked"]),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  startsTime: z.string().regex(/^\d{2}:\d{2}$/),
  endsTime: z.string().regex(/^\d{2}:\d{2}$/),
  repeat: z.enum(["once", "weekly"]),
  untilDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional().or(z.literal("")),
  notes: z.string().trim().max(180).optional().or(z.literal("")),
  view: z.enum(["day", "week"]).optional()
});

export async function createAdminBlock(formData: FormData) {
  const dateForRedirect = String(formData.get("date") ?? toDateInputValue());
  const view = parseViewParam(String(formData.get("view") ?? "day"));
  const courtIds = formData.getAll("courtIds").map(Number).filter((id) => Number.isInteger(id) && id >= 1 && id <= 5);

  const parsed = adminBlockSchema.safeParse({
    title: formData.get("title"),
    kind: formData.get("kind"),
    date: formData.get("date"),
    startsTime: formData.get("startsTime"),
    endsTime: formData.get("endsTime"),
    repeat: formData.get("repeat"),
    untilDate: formData.get("untilDate") || "",
    notes: formData.get("notes") || "",
    view: formData.get("view") || "day"
  });

  if (!parsed.success || courtIds.length === 0) redirectToCalendar(dateForRedirect, view, "error", "Admin-Termin unvollständig.");

  const { title, kind, date, startsTime, endsTime, repeat, untilDate, notes } = parsed.data;

  if (!isValidTimeOption(startsTime, adminStartTimes()) || !isValidTimeOption(endsTime, adminEndTimes())) {
    redirectToCalendar(date, view, "error", "Admin-Termine müssen im 30-Minuten-Raster innerhalb der Öffnungszeit liegen.");
  }

  if (timeToMinutes(endsTime) <= timeToMinutes(startsTime)) redirectToCalendar(date, view, "error", "Endzeit muss nach der Startzeit liegen.");
  if (repeat === "weekly" && !untilDate) redirectToCalendar(date, view, "error", "Bei wöchentlicher Wiederholung muss ein Bis-Datum gesetzt werden.");

  const { supabase, user } = await assertAdmin();

  const dates = repeat === "weekly" ? createWeeklyDates(date, untilDate || date) : [date];
  if (dates.length > MAX_WEEKLY_REPEAT_OCCURRENCES) redirectToCalendar(date, view, "error", `Bitte maximal ${MAX_WEEKLY_REPEAT_OCCURRENCES} Wiederholungen auf einmal eintragen.`);

  const rows = dates.flatMap((dateValue) => {
    const { startsAt, endsAt } = getTimeRangeLocal(dateValue, startsTime, endsTime);
    return courtIds.map((courtId) => ({
      court_id: courtId,
      user_id: null,
      created_by: user.id,
      title,
      kind: kind as BookingKind,
      starts_at: startsAt,
      ends_at: endsAt,
      notes: notes?.trim() ? notes.trim() : null
    }));
  });

  const { error } = await supabase.from("bookings").insert(rows);
  if (error) redirectToCalendar(date, view, "error", "Der feste Termin überschneidet sich mit einer vorhandenen Buchung.");

  revalidatePath("/");
  revalidatePath("/admin/bookings");
  redirectToCalendar(date, view, "success", "Fester Termin eingetragen.");
}
