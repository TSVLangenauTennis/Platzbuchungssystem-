# Echte Datenbank-Migrationen einrichten

Aktuell wird `supabase/schema.sql` von Hand gepflegt und Änderungen werden
manuell im Supabase-Dashboard (SQL Editor) ausgeführt. Das funktioniert,
kann aber mit der Zeit auseinanderdriften (ist uns schon einmal passiert:
die `announcements`-Tabelle existierte in der echten Datenbank, aber nicht
in dieser Datei).

Die Supabase-CLI löst das: Sie liest den *tatsächlichen* Stand direkt aus
deiner Datenbank aus, sodass nichts geraten werden muss. Das muss einmalig
auf deinem eigenen Rechner eingerichtet werden (nicht über den Chat hier),
weil dafür dein Supabase-Login nötig ist.

## Einmalige Einrichtung

1. Node.js muss installiert sein (hast du bereits, sonst von nodejs.org).
2. Im Projektordner (dort wo `package.json` liegt) im Terminal:
   ```
   npm install --save-dev supabase
   npx supabase login
   ```
   Das öffnet den Browser zum Einloggen bei Supabase.

3. Projekt verknüpfen (die Projekt-ID findest du in Supabase unter
   Project Settings → General → "Reference ID"):
   ```
   npx supabase link --project-ref DEINE-PROJEKT-ID
   ```

4. Den *echten* aktuellen Stand deiner Datenbank herunterladen:
   ```
   npx supabase db pull
   ```
   Das legt automatisch einen Ordner `supabase/migrations/` mit einer
   Datei an, die exakt widerspiegelt, was in deiner Datenbank wirklich
   existiert - das ersetzt dann `schema.sql` als "Quelle der Wahrheit".

## Ab jetzt: neue Änderungen

Statt SQL direkt im Supabase-Dashboard einzutippen:

```
npx supabase migration new kurzer_name_der_aenderung
```

Das legt eine neue, leere SQL-Datei im `migrations`-Ordner an. Das SQL
dort reinschreiben (kann ich dir wie gewohnt hier im Chat vorbereiten),
dann:

```
npx supabase db push
```

Das spielt die Änderung in deine echte Datenbank ein UND merkt sich
gleichzeitig im Git-Verlauf, was wann geändert wurde. So bleiben Code
und Datenbank dauerhaft synchron, ohne dass man von Hand daran denken
muss, eine Datei nachzupflegen.

## Warum das nicht ich selbst einrichten konnte

Schritt 2 und 3 brauchen deinen persönlichen Supabase-Login bzw. die
Berechtigung für dein Projekt - das kann aus Sicherheitsgründen nur auf
deinem eigenen Rechner passieren, nicht über den Chat.
