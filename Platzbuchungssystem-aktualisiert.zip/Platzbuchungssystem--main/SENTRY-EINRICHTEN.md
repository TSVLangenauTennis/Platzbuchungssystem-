# Fehler-Überwachung (Sentry) einrichten

Aktuell merkt niemand automatisch, wenn im laufenden Betrieb ein Fehler
auftritt (z.B. eine Buchung schlägt aus einem unerwarteten Grund fehl).
Sentry (kostenlose Stufe reicht locker für die Vereinsgröße) schickt dir
dann automatisch eine Benachrichtigung.

## Warum ich das nicht direkt eingebaut habe

Die Einbindung verändert `next.config.ts` (die zentrale Konfigurationsdatei).
Ich kann den Code hier nicht testweise bauen lassen (kein Internetzugang in
meiner Umgebung), und ein Fehler an dieser Stelle würde dazu führen, dass
eure Seite beim nächsten Hochladen gar nicht mehr baut. Der sichere Weg ist
deshalb der offizielle Sentry-Assistent - der prüft automatisch, welche
Next.js-Version ihr habt, und erzeugt garantiert passenden Code.

## So richtest du es ein (ca. 5 Minuten)

1. Kostenlosen Account anlegen: https://sentry.io/signup/
2. Im Projektordner im Terminal:
   ```
   npx @sentry/wizard@latest -i nextjs
   ```
3. Der Assistent fragt nach dem Login (öffnet den Browser) und richtet
   danach automatisch alles ein: die nötigen Dateien, die Änderungen an
   `next.config.ts` und eine Beispiel-Fehlerseite zum Testen.
4. Änderungen wie gewohnt committen und hochladen.

Danach bekommst du bei echten Fehlern automatisch eine E-Mail von Sentry,
inklusive genauer Stelle im Code, wo es geknallt hat - deutlich schneller,
als wenn ein Mitglied sich beschwert.

## Falls du danach Hilfe brauchst

Nach dem Einrichten kannst du mir jederzeit sagen "Sentry ist eingerichtet"
und mir bei Bedarf zeigen, was der Assistent geändert hat - dann schaue ich
gerne drüber oder helfe bei weiteren Anpassungen (z.B. welche Fehler
gemeldet werden sollen).
