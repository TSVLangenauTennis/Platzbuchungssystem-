import { test, describe } from "node:test";
import assert from "node:assert/strict";
import {
  assertBookableDate,
  assertBookableSlot,
  overlapsSlot,
  nowInClubTimezone,
  toDateInputValue,
  addMinutesToLocalIso,
  addDays
} from "../dates.ts";
import { MAX_ADVANCE_DAYS } from "../config.ts";

function assertThrows(fn: () => void, messageContains: string) {
  assert.throws(fn, (error: unknown) => {
    assert.ok(error instanceof Error);
    assert.ok(
      error.message.includes(messageContains),
      `Erwartete Fehlermeldung mit "${messageContains}", bekam: "${error.message}"`
    );
    return true;
  });
}

describe("nowInClubTimezone", () => {
  test("liefert ein gültiges Datum nah an der echten aktuellen Zeit", () => {
    const clubNow = nowInClubTimezone().getTime();
    const realNow = Date.now();
    // Die Differenz darf nur durch die reine Zeitzonen-Umrechnung entstehen
    // (max. ca. 14 Stunden weltweit) - alles darüber wäre ein echter Bug.
    const diffHours = Math.abs(clubNow - realNow) / (60 * 60 * 1000);
    assert.ok(diffHours < 15, `Zeitdifferenz zu groß: ${diffHours}h`);
  });
});

describe("overlapsSlot", () => {
  test("erkennt eine echte Überschneidung", () => {
    const overlaps = overlapsSlot(
      "2026-01-01T10:00:00", "2026-01-01T11:00:00",
      "2026-01-01T10:30:00", "2026-01-01T11:30:00"
    );
    assert.equal(overlaps, true);
  });

  test("erkennt direkt aneinandergrenzende Zeiten nicht als Überschneidung", () => {
    const overlaps = overlapsSlot(
      "2026-01-01T10:00:00", "2026-01-01T11:00:00",
      "2026-01-01T11:00:00", "2026-01-01T12:00:00"
    );
    assert.equal(overlaps, false);
  });

  test("erkennt komplett getrennte Zeiten nicht als Überschneidung", () => {
    const overlaps = overlapsSlot(
      "2026-01-01T10:00:00", "2026-01-01T11:00:00",
      "2026-01-01T14:00:00", "2026-01-01T15:00:00"
    );
    assert.equal(overlaps, false);
  });
});

describe("assertBookableDate", () => {
  test("lehnt ein Datum in der Vergangenheit ab", () => {
    assertThrows(() => assertBookableDate("2020-01-01"), "Vergangene Tage");
  });

  test("lehnt ein ungültiges Datum ab", () => {
    assertThrows(() => assertBookableDate("nicht-ein-datum"), "Ungültiges Datum");
  });

  test("erlaubt den heutigen Tag", () => {
    assert.doesNotThrow(() => assertBookableDate(toDateInputValue()));
  });

  test("erlaubt ein Datum innerhalb der Vorlauffrist", () => {
    const soon = toDateInputValue(addDays(nowInClubTimezone(), 5));
    assert.doesNotThrow(() => assertBookableDate(soon));
  });

  test("lehnt ein Datum weit jenseits der Vorlauffrist ab", () => {
    const tooFar = toDateInputValue(addDays(nowInClubTimezone(), MAX_ADVANCE_DAYS + 5));
    assertThrows(() => assertBookableDate(tooFar), "im Voraus möglich");
  });
});

describe("assertBookableSlot", () => {
  test("lehnt eine bereits vergangene Uhrzeit heute ab", () => {
    const today = toDateInputValue();
    assertThrows(() => assertBookableSlot(today, "00:00"), "Vergangene Uhrzeiten");
  });

  test("lehnt eine ungültige Startzeit ab", () => {
    const today = toDateInputValue();
    assertThrows(() => assertBookableSlot(today, "nicht-eine-uhrzeit"), "Ungültige Startzeit");
  });

  test("erlaubt eine Zeit ohne Vorlauffrist-Regel, solange sie in der Zukunft liegt", () => {
    const tomorrow = toDateInputValue(addDays(nowInClubTimezone(), 1));
    assert.doesNotThrow(() => assertBookableSlot(tomorrow, "12:00"));
  });

  test("2-Stunden-Regel: lehnt eine Buchung 30 Minuten vor Beginn ab", () => {
    const now = nowInClubTimezone();
    const nowDate = toDateInputValue(now);
    const nowTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
    const soon = addMinutesToLocalIso(nowDate, nowTime, 30);
    const [soonDate, soonTimePart] = soon.split("T");
    const soonTime = soonTimePart.slice(0, 5);

    assertThrows(
      () => assertBookableSlot(soonDate, soonTime, { leadMinutes: 120 }),
      "vor Spielbeginn möglich"
    );
  });

  test("2-Stunden-Regel: erlaubt eine Buchung 3 Stunden vor Beginn", () => {
    const now = nowInClubTimezone();
    const nowDate = toDateInputValue(now);
    const nowTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
    const later = addMinutesToLocalIso(nowDate, nowTime, 3 * 60);
    const [laterDate, laterTimePart] = later.split("T");
    const laterTime = laterTimePart.slice(0, 5);

    assert.doesNotThrow(() => assertBookableSlot(laterDate, laterTime, { leadMinutes: 120 }));
  });

  test("Admin-Buchungen (ohne leadMinutes) sind von der 2-Stunden-Regel ausgenommen", () => {
    const now = nowInClubTimezone();
    const nowDate = toDateInputValue(now);
    const nowTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
    const soon = addMinutesToLocalIso(nowDate, nowTime, 10);
    const [soonDate, soonTimePart] = soon.split("T");
    const soonTime = soonTimePart.slice(0, 5);

    // Ohne { leadMinutes } (wie bookCourtForMember es aufruft) darf das nicht
    // an der 2-Stunden-Regel scheitern.
    assert.doesNotThrow(() => assertBookableSlot(soonDate, soonTime));
  });
});
