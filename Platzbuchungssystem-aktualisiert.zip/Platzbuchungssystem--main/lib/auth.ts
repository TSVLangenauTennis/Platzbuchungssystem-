import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { PROFILE_COLUMNS } from "@/lib/types";
import type { Profile } from "@/lib/types";

// Wird von jeder Admin-Seite am Anfang aufgerufen, statt den Block
// "User laden -> Profil laden -> is_admin prüfen -> sonst redirect"
// in jeder Datei einzeln zu wiederholen.
export async function requireAdmin() {
  const supabase = await createClient();
  const { data: userData } = await supabase.auth.getUser();
  const user = userData.user;
  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select(PROFILE_COLUMNS)
    .eq("id", user.id)
    .single<Profile>();

  if (!profile?.is_admin) redirect("/");

  return { supabase, user, profile };
}
