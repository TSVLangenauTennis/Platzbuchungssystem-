import Link from "next/link";
import { CLUB_CONTACT_EMAIL } from "@/lib/config";

export default function DatenschutzPage() {
  return (
    <main className="page narrow-page">
      <header className="header">
        <div className="brand">
          <h1>Datenschutzerklärung</h1>
          <p>Informationen zur Verarbeitung personenbezogener Daten (DSGVO)</p>
        </div>
        <Link className="button secondary" href="/">Zur Buchung</Link>
      </header>

      <section className="card account-card form-stack">
        <p>
          Diese Erklärung betrifft ausschließlich das Online-Platzbuchungssystem. Für die allgemeine
          Vereinsmitgliedschaft (Beitragsverwaltung, Lohnabrechnung, Fotos von Veranstaltungen usw.) gilt zusätzlich
          die allgemeine Datenschutzerklärung des TSV Langenau auf dessen Hauptwebsite.
        </p>

        <h2>1. Name und Kontaktdaten des Verantwortlichen</h2>
        <p>
          Verantwortlicher im Sinne des Art. 4 Nr. 7 DSGVO ist TSV Langenau 1861 e.V., Angertorstraße 39,
          89129 Langenau.<br />
          Vorstandsvorsitzender: Thomas Martin<br />
          E-Mail: {CLUB_CONTACT_EMAIL}
        </p>

        <h2>2. Kontaktdaten des Datenschutzbeauftragten</h2>
        <p>Ein Datenschutzbeauftragter ist im TSV Langenau nicht notwendig und ist daher auch nicht bestellt.</p>

        <h2>3. Zwecke und Rechtsgrundlage der Verarbeitung</h2>
        <p>Für das Platzbuchungssystem verarbeiten wir folgende personenbezogene Daten:</p>
        <p>
          a) Zum Zwecke der Kontoerstellung und Anmeldung werden Name, E-Mail-Adresse sowie optional Telefonnummer
          und Mitgliedsnummer verarbeitet. Die Rechtsgrundlage hierfür ist Art. 6 Abs. 1 lit. b) DSGVO.
        </p>
        <p>
          b) Zum Zwecke der Platzbuchung werden Buchungsdaten (Platz, Datum, Uhrzeit, ggf. Hinweistext) verarbeitet.
          Die Rechtsgrundlage hierfür ist Art. 6 Abs. 1 lit. b) DSGVO sowie das berechtigte Interesse an einer
          geordneten Platzverwaltung (Art. 6 Abs. 1 lit. f) DSGVO).
        </p>
        <p>
          c) Verbesserungsvorschläge werden anonym gespeichert - wer welchen Vorschlag eingereicht hat, wird
          technisch nicht miterfasst.
        </p>
        <p>
          d) Für die Anmeldung wird ein technisch notwendiges Session-Cookie gesetzt (Supabase Auth). Dieses fällt
          unter § 25 Abs. 2 Nr. 2 TTDSG und benötigt keine gesonderte Einwilligung. Cookies zu Werbe- oder
          Tracking-Zwecken werden nicht eingesetzt.
        </p>

        <h2>4. Empfänger der personenbezogenen Daten</h2>
        <p>
          Für den technischen Betrieb setzen wir Supabase (Datenbank und Login) und Vercel (Hosting) als
          Auftragsverarbeiter nach Art. 28 DSGVO ein.{" "}
          <span className="placeholder-fill">Bitte prüfen: Sind mit beiden Auftragsverarbeitungsverträge (AVV) abgeschlossen und liegen die Server innerhalb der EU/des EWR? Beide Anbieter stellen die nötigen Angaben/Verträge kostenlos im jeweiligen Dashboard bereit.</span>
        </p>

        <h2>5. Speicherdauer</h2>
        <p>
          Kontodaten werden 2 Jahre nach Beendigung der Vereinsmitgliedschaft gelöscht. Buchungsdaten werden{" "}
          <span className="placeholder-fill">Zeitraum eintragen, z. B. 12 Monate nach Nutzung</span> aufbewahrt.
        </p>

        <h2>Betroffenenrechte</h2>
        <p>
          Ihnen steht ein Recht auf Auskunft (Art. 15 DSGVO), Berichtigung (Art. 16 DSGVO), Löschung (Art. 17 DSGVO),
          Einschränkung der Verarbeitung (Art. 18 DSGVO) sowie Datenübertragbarkeit (Art. 20 DSGVO) zu. Wenden Sie
          sich dazu an {CLUB_CONTACT_EMAIL}.
        </p>
        <p>
          Ihnen steht ferner ein Beschwerderecht bei einer Datenschutz-Aufsichtsbehörde zu, zuständig ist der
          Landesbeauftragte für den Datenschutz und die Informationsfreiheit Baden-Württemberg (LfDI),
          Königstraße 10a, 70173 Stuttgart.
        </p>

        <h2>Pflicht zur Bereitstellung der Daten</h2>
        <p>
          Die Bereitstellung von Name und E-Mail-Adresse ist für die Registrierung und Nutzung der Platzbuchung
          notwendig. Ohne diese Daten kann keine Kontoerstellung und damit keine Buchung erfolgen.
        </p>

        <h2>Kontakt</h2>
        <p>Bei Fragen zum Datenschutz: {CLUB_CONTACT_EMAIL}</p>
      </section>
    </main>
  );
}
