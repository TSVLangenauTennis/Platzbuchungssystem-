import { redirect } from "next/navigation";
import { MAX_ADVANCE_DAYS } from "@/lib/config";
import { addDays, nowInClubTimezone, toDateInputValue } from "@/lib/dates";
import { createClient } from "@/lib/supabase/server";
import type { CalendarView } from "@/lib/types";

// Ersetzt die frühere Sammlung von sieben fast identischen
// redirectToX(type, message)-Funktionen. Jede Seite ruft weiterhin ihre
// eigene kleine, klar benannte Variante auf (siehe unten) - die eigentliche
// URL-Bau-Logik steht aber nur noch einmal hier.
export function redirectWithMessage(
  path: string,
  type: "success" | "error",
  message: string,
  extraParams?: Record<string, string>
): never {
  const params = new URLSearchParams({ ...extraParams, [type]: message });
  redirect(`${path}?${params.toString()}`);
}

export function redirectToCalendar(date: string, view: CalendarView, type: "success" | "error", message: string): never {
  redirectWithMessage("/", type, message, { date, view });
}

export function redirectToHome(type: "success" | "error", message: string): never {
  redirectWithMessage("/", type, message);
}

export function redirectToMembers(type: "success" | "error", message: string): never {
  redirectWithMessage("/admin/members", type, message);
}

export function redirectToAccount(type: "success" | "error", message: string): never {
  redirectWithMessage("/account", type, message);
}

export function redirectToAdminBookings(type: "success" | "error", message: string): never {
  redirectWithMessage("/admin/bookings", type, message);
}

export function redirectToCourts(type: "success" | "error", message: string): never {
  redirectWithMessage("/admin/courts", type, message);
}

export function redirectToAnnouncements(type: "success" | "error", message: string): never {
  redirectWithMessage("/ankundigungen", type, message);
}

export function assertBookableDate(dateValue: string) {
  const today = nowInClubTimezone();
  const earliest = new Date(`${toDateInputValue(today)}T00:00:00`);
  const latest = addDays(earliest, MAX_ADVANCE_DAYS);
  const selected = new Date(`${dateValue}T00:00:00`);

  if (Number.isNaN(selected.getTime())) throw new Error("Ungültiges Datum.");
  if (selected < earliest) throw new Error("Vergangene Tage können nicht gebucht werden.");
  if (selected > latest) throw new Error(`Buchungen sind maximal ${MAX_ADVANCE_DAYS} Tage im Voraus möglich.`);
}

export function assertBookableSlot(dateValue: string, startTime: string, options?: { leadMinutes?: number }) {
  assertBookableDate(dateValue);
  const startsAt = new Date(`${dateValue}T${startTime}:00`);
  if (Number.isNaN(startsAt.getTime())) throw new Error("Ungültige Startzeit.");
  const now = nowInClubTimezone();
  if (startsAt.getTime() <= now.getTime()) throw new Error("Vergangene Uhrzeiten können nicht gebucht werden.");

  const leadMinutes = options?.leadMinutes ?? 0;
  if (leadMinutes > 0 && startsAt.getTime() - now.getTime() < leadMinutes * 60_000) {
    const hours = leadMinutes / 60;
    throw new Error(`Buchungen sind nur bis ${hours} Stunde${hours === 1 ? "" : "n"} vor Spielbeginn möglich.`);
  }
}

export async function getCurrentUserOrRedirect() {
  const supabase = await createClient();
  const { data: userData } = await supabase.auth.getUser();
  const user = userData.user;
  if (!user) redirect("/login");
  return { supabase, user };
}

export async function assertAdmin() {
  const { supabase, user } = await getCurrentUserOrRedirect();
  const { data: profile } = await supabase.from("profiles").select("is_admin").eq("id", user.id).single();
  if (!profile?.is_admin) redirect("/");
  return { supabase, user };
}
