import Link from "next/link";
import { CLUB_CONTACT_EMAIL } from "@/lib/config";

export default function ImpressumPage() {
  return (
    <main className="page narrow-page">
      <header className="header">
        <div className="brand">
          <h1>Impressum</h1>
          <p>Angaben gemäß § 5 Digitale-Dienste-Gesetz (DDG)</p>
        </div>
        <Link className="button secondary" href="/">Zur Buchung</Link>
      </header>

      <section className="card account-card form-stack">
        <p>
          Dieses Impressum gilt für die Plattform zur Online-Platzbuchung des TSV Langenau 1861 e.V.,
          Abteilung Tennis.
        </p>

        <p className="notice error">
          Registergericht und Registernummer fehlen noch (<span className="placeholder-fill">so gekennzeichnet</span>) -
          bitte beim Vorstand nachfragen und hier ergänzen.
        </p>

        <h2>Verein</h2>
        <p>
          TSV Langenau 1861 e.V.<br />
          Angertorstraße 39<br />
          89129 Langenau<br />
          E-Mail: info@tsv-langenau.de
        </p>

        <h2>Vertretungsberechtigt</h2>
        <p>
          Thomas Martin (Vorstandsvorsitzender)<br />
          Dahlienweg 6/3<br />
          89129 Langenau<br />
          Telefon: 07345/22650<br />
          E-Mail: tmartin.langenau@gmx.de
        </p>

        <h2>Registereintrag</h2>
        <p>
          Registergericht: <span className="placeholder-fill">vermutlich Amtsgericht Ulm - bitte bestätigen</span><br />
          Registernummer: <span className="placeholder-fill">Registernummer eintragen (VR ...)</span>
        </p>

        <h2>Kontakt zum Buchungssystem</h2>
        <p>E-Mail: {CLUB_CONTACT_EMAIL}</p>

        <h2>Verantwortlich für den Inhalt nach § 18 Abs. 2 MStV</h2>
        <p>Thomas Martin, Anschrift wie oben.</p>

        <h2>Urheberrecht</h2>
        <p>
          Alle Rechte vorbehalten. Text, Bilder, Grafiken sowie deren Anordnung auf dieser Website unterliegen dem
          Schutz des Urheberrechts und anderer Schutzgesetze. Der Inhalt darf nicht zu kommerziellen Zwecken kopiert,
          verbreitet oder verändert werden.
        </p>

        <h2>Haftungsausschluss</h2>
        <p>
          Die bereitgestellten Informationen auf dieser Website wurden sorgfältig geprüft und werden regelmäßig
          aktualisiert. Es kann jedoch keine Garantie dafür übernommen werden, dass die Angaben jederzeit vollständig,
          richtig und aktuell sind. Alle Angaben können ohne vorherige Ankündigung ergänzt, entfernt oder geändert
          werden.
        </p>

        <h2>Hinweis zu Links</h2>
        <p>
          Mit der Anbringung eines Links werden ggf. die Inhalte der verlinkten Seite mit zu verantworten
          (LG Hamburg, Urteil vom 12.05.1998 - 312 O 85/98). Wir distanzieren uns ausdrücklich von allen Inhalten
          aller gelinkten Seiten.
        </p>

        <h2>Streitschlichtung</h2>
        <p>
          Die Europäische Kommission stellt eine Plattform zur Online-Streitbeilegung (OS) bereit:{" "}
          <a href="https://ec.europa.eu/consumers/odr/" target="_blank" rel="noopener noreferrer">
            https://ec.europa.eu/consumers/odr/
          </a>
          . Wir sind zur Teilnahme an einem Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle
          nicht verpflichtet und nehmen daran nicht teil.
        </p>
      </section>
    </main>
  );
}
