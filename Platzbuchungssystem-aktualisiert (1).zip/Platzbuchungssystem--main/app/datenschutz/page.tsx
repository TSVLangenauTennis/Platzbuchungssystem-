import Link from "next/link";
import { CLUB_CONTACT_EMAIL } from "@/lib/config";

export default function DatenschutzPage() {
  return (
    <main className="page narrow-page">
      <header className="header">
        <div className="brand">
          <h1>Datenschutzerklärung</h1>
          <p>Informationen zur Verarbeitung personenbezogener Daten (DSGVO)</p>
        </div>
        <Link className="button secondary" href="/">Zur Buchung</Link>
      </header>

      <section className="card account-card form-stack">
        <p>
          Diese Erklärung betrifft ausschließlich das Online-Platzbuchungssystem. Für die allgemeine
          Vereinsmitgliedschaft (Beitragsverwaltung, Lohnabrechnung, Fotos von Veranstaltungen usw.) gilt zusätzlich
          die allgemeine Datenschutzerklärung des TSV Langenau auf dessen Hauptwebsite.
        </p>

        <h2>1. Verantwortlicher</h2>
        <p>
          Verantwortlich im Sinne des Art. 4 Nr. 7 DSGVO ist:<br />
          TSV Langenau 1861 e.V.<br />
          Angertorstraße 39, 89129 Langenau<br />
          Vertreten durch: Thomas Martin (Vorstandsvorsitzender)<br />
          E-Mail: {CLUB_CONTACT_EMAIL}
        </p>

        <h2>2. Datenschutzbeauftragter</h2>
        <p>Ein Datenschutzbeauftragter ist beim TSV Langenau nicht gesetzlich vorgeschrieben und daher nicht bestellt.</p>

        <h2>3. Welche Daten wir verarbeiten</h2>
        <p>Zur Nutzung der Platzbuchung verarbeiten wir:</p>
        <ul>
          <li>Name</li>
          <li>E-Mail-Adresse</li>
          <li>Telefonnummer (optional)</li>
          <li>Mitgliedsnummer (optional)</li>
          <li>Buchungsdaten (Platz, Datum, Uhrzeit, ggf. Hinweistext)</li>
          <li>Registrierungs- und Freigabestatus des Kontos</li>
        </ul>
        <p>
          Anonyme Verbesserungsvorschläge werden ohne Personenbezug gespeichert - wer welchen Vorschlag
          eingereicht hat, wird technisch nicht miterfasst.
        </p>

        <h2>4. Zweck und Rechtsgrundlage</h2>
        <p>
          Die Verarbeitung erfolgt zur Organisation der Tennisplatz-Nutzung im Rahmen der Vereinsmitgliedschaft
          (Art. 6 Abs. 1 lit. b DSGVO) sowie zur Wahrung berechtigter Interessen des Vereins an einer geordneten
          Platzverwaltung (Art. 6 Abs. 1 lit. f DSGVO).
        </p>

        <h2>5. Speicherdauer</h2>
        <p>
          Kontodaten werden 2 Jahre nach Beendigung der Vereinsmitgliedschaft gelöscht, sofern keine gesetzliche
          Aufbewahrungspflicht entgegensteht. Buchungsdaten werden{" "}
          <span className="placeholder-fill">Zeitraum eintragen, z. B. 12 Monate nach Nutzung</span> aufbewahrt.
          Anonyme Verbesserungsvorschläge werden{" "}
          <span className="placeholder-fill">Zeitraum eintragen, z. B. bis zur Bearbeitung durch den Vorstand</span> gespeichert.
        </p>

        <h2>6. Cookies und technische Speicherung</h2>
        <p>
          Wir setzen ausschließlich technisch notwendige Cookies ein, die für den Login und die Aufrechterhaltung
          Ihrer Sitzung erforderlich sind (Session-Cookies von Supabase Auth). Diese fallen unter die Ausnahme des
          § 25 Abs. 2 Nr. 2 TTDSG und benötigen keine gesonderte Einwilligung. Es werden keine Cookies zu Werbe-
          oder Tracking-Zwecken eingesetzt.
        </p>

        <h2>7. Empfänger / Auftragsverarbeiter</h2>
        <p>
          Für den technischen Betrieb setzen wir folgende Dienstleister als Auftragsverarbeiter nach Art. 28 DSGVO
          ein:
        </p>
        <ul>
          <li>Supabase (Datenbank und Login)</li>
          <li>Vercel (Hosting der Webseite)</li>
        </ul>
        <p className="notice error">
          <span className="placeholder-fill">Bitte prüfen: Sind mit Supabase und Vercel jeweils Auftragsverarbeitungsverträge (AVV) abgeschlossen? Beide bieten das kostenlos über ihre Dashboards an.</span>
        </p>

        <h2>8. Datenübermittlung in Drittländer</h2>
        <p>
          Je nachdem, welcher Serverstandort bei Supabase und Vercel für dieses Projekt eingestellt ist, können
          Daten auch außerhalb der EU/des EWR verarbeitet werden (z. B. in den USA).{" "}
          <span className="placeholder-fill">Bitte im Supabase- und Vercel-Dashboard den eingestellten Serverstandort prüfen und hier eintragen. Bei Verarbeitung außerhalb der EU/des EWR: Absicherung z. B. durch EU-Standardvertragsklauseln, die beide Anbieter üblicherweise automatisch einschließen - bitte bestätigen.</span>
        </p>

        <h2>9. Automatisierte Entscheidungsfindung</h2>
        <p>Eine automatisierte Entscheidungsfindung einschließlich Profiling im Sinne des Art. 22 DSGVO findet nicht statt.</p>

        <h2>10. Pflicht zur Bereitstellung der Daten</h2>
        <p>
          Die Angabe von Name und E-Mail-Adresse ist für die Registrierung und Nutzung der Platzbuchung
          erforderlich. Ohne diese Angaben ist eine Kontoerstellung und damit eine Buchung nicht möglich.
        </p>

        <h2>11. Ihre Rechte</h2>
        <p>
          Sie haben das Recht auf Auskunft (Art. 15 DSGVO), Berichtigung (Art. 16 DSGVO), Löschung (Art. 17 DSGVO),
          Einschränkung der Verarbeitung (Art. 18 DSGVO), Widerspruch (Art. 21 DSGVO) sowie Datenübertragbarkeit
          (Art. 20 DSGVO). Wenden Sie sich dazu an {CLUB_CONTACT_EMAIL}.
        </p>
        <p>
          Außerdem haben Sie das Recht, sich bei einer Datenschutz-Aufsichtsbehörde zu beschweren, zuständig ist:<br />
          Der Landesbeauftragte für den Datenschutz und die Informationsfreiheit Baden-Württemberg (LfDI),
          Königstraße 10a, 70173 Stuttgart.
        </p>

        <h2>12. Kontakt</h2>
        <p>Bei Fragen zum Datenschutz: {CLUB_CONTACT_EMAIL}</p>
      </section>
    </main>
  );
}
